
@extends('layout')

@section('content')
<p>A quick brown fox jump over the lazy dog.</p>
@endsection

@extends('layouts.app')

@section('content')
<div class="container">
  <div class="row">
      <div class="col-md-3 col-sm-3">
          <div class="panel panel-info">
              <div class="panel-heading text-center">
                  POSTED
              </div>
              <div class="panel-body text-center">
                  <h1 class="text-center">{{ $posts_count }}</h1>
              </div>

          </div>
      </div>
      <div class="col-md-3 col-sm-3">
          <div class="panel panel-danger">
              <div class="panel-heading text-center">
                  TRASHED
              </div>
              <div class="panel-body text-center">
                  <h1 class="text-center">{{ $trashed_count}}</h1>
              </div>

          </div>
      </div>
      <div class="col-md-3 col-sm-3">
          <div class="panel panel-success">
              <div class="panel-heading text-center">
                  USERS
              </div>
              <div class="panel-body text-center">
                  <h1 class="text-center">{{ $users_count}}</h1>
              </div>

          </div>
      </div>
      <div class="col-md-3 col-sm-3">
          <div class="panel panel-primary">
              <div class="panel-heading text-center">
                  CATEGORIES
              </div>
              <div class="panel-body text-center">
                  <h1 class="text-center">{{ $trashed_count}}</h1>
              </div>

          </div>
      </div>
  </div>
</div>
<!--
<div class="col-md-3 col-sm-3">
    <div class="panel panel-info">
        <div class="panel-heading text-center">
            PUBLISHED POSTS
        </div>
        <div class="panel-body text-center">
            <h1 class="text-center">424</h1>
        </div>

    </div>
</div>

<div class="col-md-6 col-sm-6">
    <div class="panel panel-info">
        <div class="panel-heading text-center">
            PUBLISHED POSTS
        </div>
        <div class="panel-body text-center">
            <h1 class="text-center">424</h1>
        </div>

    </div>
</div>
<div class="col-md-6 col-sm-6">
    <div class="panel panel-info">
        <div class="panel-heading text-center">
            PUBLISHED POSTS
        </div>
        <div class="panel-body text-center">
            <h1 class="text-center">424</h1>
        </div>

    </div>
</div>
<div class="col-md-12 col-sm-12">
    <div class="panel panel-info">
        <div class="panel-heading text-center">
            PUBLISHED POSTSa quick brown fos jump over the lazy dog a over broen fox jump over the lazy dg a a a  quick brown fox jump over the e
        </div>
        <div class="panel-body text-center">
            <h1 class="text-center">424</h1>
        </div>

    </div>
</div>
-->
@endsection

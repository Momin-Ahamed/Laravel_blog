@extends('layouts.app')

@section('content')



@include('admin.include.errors')

   <div class="panel panel-default">
     <div class="panel-heading text-center" >
    Edit Your Profile
     </div>
     <div class="panel-body">
         <form action="{{ route('user.profile.update') }}" method="post" enctype="multipart/form-data" >
            {{ csrf_field() }}




            <div class="from-group">
                    <label for="name">User</label>
                    <input type="text" name="name" value="{{ $user->name }}" class="form-control">
            </div>
            <div class="from-group">
                    <label for="name">E-mail</label>
                    <input type="email" name="email" value="{{ $user->email }}" class="form-control">
            </div>
            <div class="from-group">
                    <label for="name">Password</label>
                    <input type="password" name="password" class="form-control">
            </div>
            <div class="from-group">
                    <label for="name">Upload New Avatar</label>
                    <input type="file" name="avatar" class="form-control">
            </div>





    <!--dangerous section-->
        <div class="from-group">
                <label for="name">FaceBook Profile</label>

                <input type="text" name="facebook" value="{{ $user->profile->facebook }}" class="form-control">
        </div>
        <div class="from-group">
                <label for="name">Youtube</label>
                <input type="text" name="youtube" value="{{ $user->profile->youtube }}" class="form-control">
        </div>
        <div class="from-group">
                <label for="name">About</label>
                <textarea name="about"  id="about" rows="8" cols="80">{{ $user->profile->about }}</textarea>
        </div>
        <!--end dangerous-->






            <div class="form-group">
                <div class="text-center">
                    <button class="btn btn-success" type="submit">
                    update
                </button>
                </div>

            </div>
        </form>
        </div>
   </div>

@endsection

@extends('layout')

@section('content')

<div class="row">
    <div class="col-lg-6 col-lg-offset-3">
        <form action="{{ route('todos.save',['id' =>$todo->id]) }}" method="post">
        {{ csrf_field() }}
            <input type="text" class="form-control input-lg" placeholder="create new to do list" value="{{ $todo->todo}}" name="todo">
        </form>


    </div>

<div>

<br/>
<hr/>




@endsection

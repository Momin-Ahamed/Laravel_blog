<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
//use App\Todo;
use Session;
//use DB;***$petani = DB::table('todos')->get();
use App\Todo;

class TodosController extends Controller
{
    public function index(){
       // $petani = DB::table('todos')->get();
        $petani = Todo::all();
         return view('todos', ['petani' => $petani]);
    }

    public function store(Request $request){
           // dd($request);
           $todo = new Todo;
           $todo->todo = $request->todo;
           $todo->save();
           Session::flash('success','Your session created successfully');
           return redirect()->back();
    }
    public function delete($id){
            //dd($id);
            $todo = Todo::find($id);
            $todo->delete();
            Session::flash('success','Your session deleted successfully');
            return redirect()->back();
    }
    public function update($id){
        $todo = Todo::find($id);
        Session::flash('success','Your session updated successfully');
        return view('update',['todo' => $todo]);
    }
    public function save(Request $request, $id){
        $todo = Todo::find($id);
        $todo->todo = $request->todo;
        $todo->save();
        Session::flash('success','Your session uPd successfully');
        return redirect()->route('todo');

    }
    public function completed($id){
        $todo = Todo::find($id);
        $todo->completed = 1;
        $todo->save();
        Session::flash('success','Your session was marked successfully');
        return redirect()->back();

    }
}

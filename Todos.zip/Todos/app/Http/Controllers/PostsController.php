<?php

namespace App\Http\Controllers;
use Auth;
use App\Category;
use App\Post;
use App\Tag;
use App\User;
use App\Profile;
use Session;
use Illuminate\Http\Request;

class PostsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('admin.posts.index')->with('posts', Post::all());
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */

 public function create(){

     $categories = Category::all();
     $tags = Tag::all();

     if( $categories->count() == 0 || $tags->count() ==0)
     {

         Session::flash('info', 'You Must have some categories & tags before attepting to create post');
         return redirect()->back();
     }
            return view('admin.posts.create')
            ->with('categories',$categories)
            ->with('tags',$tags);// Category::all()


     }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //dd($request->all());

        $this->validate($request,[
            'title' =>'required',
            'content'=>'required',
            'category_id' =>'required',
            'featured' =>'required|image',
            'tags' => 'required'


        ]);

        $featured = $request->featured;
        $featured_new_name = time().$featured->getClientOriginalName();
        $featured->move('uploads/posts', $featured_new_name );

        $post = Post::create([
            'title' =>$request->title,
            'content' =>$request->content,
            'category_id' =>$request->category_id,
            'featured' =>'uploads/posts/'.$featured_new_name,
            'slug' =>str_slug($request->title),
            'user_id' =>Auth::id()

        ]);

        $post->tags()->attach($request->tags);

        Session::flash('success','Your Post Created  successfully');
        return redirect()->back();

    }

    public function destroy($id){
        $post = Post::find($id);
        $post->delete();
        Session::flash('success','The post was just trashed');
        return redirect()->back();
    }
    public function trashed(){
        $post = Post::onlyTrashed()->get();
        return view('admin.posts.trashed')->with('posts',$post);
        //dd($post);
    }

    public function kill($id){
        $post = Post::withTrashed()->where('id', $id)->first();
        //dd($post);
        $post->forceDelete();
        Session::flash('success',' post Deleted  Permanently');

        return redirect()->back();

    }

    public function restore($id){
        $post = Post::withTrashed()->where('id', $id)->first();
        $post->restore();
        Session::flash('success',' post Restore Successfully');
        return redirect()->route('posts');
}
    public function edit($id){
        $post = Post::find($id);
        return view('admin.posts.edit')->with('post', $post)
        ->with('categories', Category::all())
        ->with('tags', Tag::all());
    }

    public function update(Request $request, $id){

        $this->validate($request,[
            'title' =>'required',
            'content'=>'required',
            'category_id' =>'required',
        ]);
            $post = Post::find($id);

            if($request->hasFile('featured'))
            {
                $featured = $request->featured;
                $featured_new_name = time() . $featured->getClientOriginalName();
                $featured->move('uploads/posts', $featured_new_name);

                $post->$featured = 'uploads/posts/'.$featured_new_name;
            }
            $post->title = $request->title;
            $post->content = $request->content;
            $post->category_id = $request->category_id;

            $post->save();

            $post->tags()->sync($request->tags);
            Session::flash('success',' post updated Successfully');
            return redirect()->route('posts');





    }


 }

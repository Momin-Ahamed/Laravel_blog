<?php

/* Email subscribing **/
Route::post('/subscribe', function(){
    $email = request('email');

    Newsletter::subscribe($email);

    Session::flash('subscribed','Successfully subscribed');
    return redirect()->back();
});

/*Check Reletionship*/
Route::get('/test', function () {
    //return App\User::find(9)->profile;
    //dd(  App\User::find(1)->profile);
    return App\Category::with('childs')
    ->where('p_id',0)
    ->get();

});

/*Route::get('/', function () {
    return view('welcome');
});*/

/* show page*/
Route::get('/',[
    'uses'=> 'FrontEndController@index'
    ]);

/* find searcing result*/
Route::get('/result', function(){
    $post =\App\Post::where('title','like', '%' .request('query') . '%')->get();
    return view('results')->with('posts', $post)
                ->with('title','result :' .request('query'))
                ->with('settings', \App\Setting::first())
                ->with('categories', \App\Category::take(6)->get())
                ->with('query', request('query'));
});

//Route::get('/new','PageController@new');

/* start todo crud operation*/
Route::get('/new',[
    'uses'=> 'PageController@new'
    ]);

Route::get('/todo',[
    'uses' =>'TodosController@index',
    'as' =>'todo'
]);


Route::get('/todo/delete/{id}',
[
'uses' => 'TodosController@delete',
'as'  => 'todo.delete'
]);
Route::get('/todo.update/{id}',
[
'uses' => 'TodosController@update',
'as'  => 'todo.update'
]);

Route::post('/create/todo',[
    'uses' =>'TodosController@store'
]);

Route::post('/todo/save/{id}',[
    'uses' =>'TodosController@save',
    'as' =>'todos.save'
]);
Route::get('/todos/completed/{id}',[
    'uses' =>'TodosController@completed',
    'as'  =>'todos.completed'
]);

/* end todo crud operation*/

/* show single page*/
Route::get('/post/{slug}',[
    'uses' =>'FrontEndController@singlePost',
    'as' =>'post.single'
]);
/* show category wise*/
Route::get('/category/{id}',[
    'uses' =>'FrontEndController@category',
    'as' =>'category.single'
]);
/* show tagw wise*/
Route::get('/tag/{id}',[
    'uses' =>'FrontEndController@tag',
    'as' =>'tag.single'
]);
Auth::routes();




Route::group(['prefix'=>'admin','middleware'=>'auth'],function(){

    Route::get('/dashboard', [
        'uses'=>'HomeController@index',
        'as' => 'dashboard'
        ]);
    Route::get('/post/create',[
        'uses' =>'PostsController@create',
        'as' =>'post.create'
    ]);

   Route::post('/post/store',[
        'uses' =>'PostsController@store',
        'as' =>'post.store'
    ]);

    Route::get('/post/delete/{id}',[
         'uses' =>'PostsController@destroy',
         'as' =>'post.delete'
     ]);

    //post.delete
    Route::get('/posts',[
        'uses' =>'PostsController@index',
        'as' =>'posts'
    ]);

    Route::get('/posts/trashed',[
        'uses' =>'PostsController@trashed',
        'as' =>'posts.trashed'
    ]);
    Route::get('/posts/kill/{id}',[
        'uses' =>'PostsController@kill',
        'as' =>'post.kill'
    ]);
    Route::get('/posts/restore/{id}',[
        'uses' =>'PostsController@restore',
        'as' =>'post.restore'
    ]);
    Route::get('/posts/edit/{id}',[
        'uses' =>'PostsController@edit',
        'as' =>'post.edit'
    ]);

    Route::post('/posts/update/{id}',[
        'uses' =>'PostsController@update',
        'as' =>'post.update'
    ]);



    Route::get('/category/create',[
        'uses' =>'categoriesController@create',
        'as' =>'category.create'
    ]);
   // [category.store
    Route::post('/category/store',[
        'uses' =>'categoriesController@store',
        'as' =>'category.store'
    ]);
    Route::get('/categories',[
        'uses' =>'categoriesController@index',
        'as' =>'categories'
    ]);
    Route::get('/category/edit/{id}',[
        'uses' =>'categoriesController@edit',
        'as' =>'category.edit'
    ]);
    Route::get('/category/destory/{id}',[
        'uses' =>'categoriesController@destroy',
        'as' =>'category.destroy'
    ]);

    Route::post('/category/update/{id}',[
        'uses' =>'categoriesController@update',
        'as' =>'category.update'
    ]);
    //category.update

    Route::get('/tags',[
        'uses' =>'TagsController@index',
        'as' =>'tags'
        ]);

Route::get('/tag/create',[
    'uses' =>'TagsController@create',
    'as' =>'tag.create'
    ]);
    Route::post('/tag/store',[
        'uses' =>'TagsController@store',
        'as' =>'tag.store'
    ]);
    Route::get('/tags/edit/{id}',[
        'uses' =>'TagsController@edit',
        'as' =>'tag.edit'
        ]);


    Route::post('/tags/update/{id}',[
            'uses' =>'TagsController@update',
            'as' =>'tag.update'
            ]);
    Route::get('/tags/delete/{id}',[
        'uses' =>'TagsController@destroy',
        'as' =>'tag.delete'
        ]);
    Route::get('/users',[
            'uses' =>'UsersController@index',
            'as' =>'users'
            ]);

    Route::get('/user/create',[
            'uses' =>'UsersController@create',
            'as' =>'user.create'
            ]);

    Route::post('/user/store',[
        'uses' =>'UsersController@store',
        'as' =>'user.store'
    ]);
    //
    Route::get('/user/admin/{id}',[
        'uses' =>'UsersController@admin',
        'as' =>'user.admin'
    ]);
    //->middleware('admin')

    Route::get('/user/not-admin/{id}',[
        'uses' =>'UsersController@not_admin',
        'as' =>'user.not.admin'
    ]);

    Route::get('/user/profile',[
            'uses' =>'ProfileController@index',
            'as' =>'user.profile'
            ]);
    Route::get('/user/delete/{id}',[
        'uses' =>'UsersController@destroy',
        'as' =>'user.delete'
        ]);

    Route::post('/profile/user/update',[
            'uses' =>'ProfileController@update',
            'as' =>'user.profile.update'
                    ]);
//
Route::get('/settings',[
    'uses' =>'SettingsController@index',
    'as' =>'settings'
    ]);

Route::post('/settings/update',[
        'uses' =>'SettingsController@update',
        'as' =>'settings.update'
        ]);



        });
